<?php
$json_data = '[
    {"name":"John Garg","age":"15","school":"Ahlcon Public school"},
    {"name":"Smith Soy","age":"16","school":"St. Marie school"},
    {"name":"Charle Rena","age":"16","school":"St. Columba school"}
]';

$data = json_decode($json_data, true);
?>

<table border="1" cellpadding="5" cellspacing="0">
    <tr>
        <th>Name</th>
        <th>Age</th>
        <th>School</th>
    </tr>
    <?php foreach($data as $student): ?>
        <tr>
            <td><?= $student['name'] ?></td>
            <td><?= $student['age'] ?></td>
            <td><?= $student['school'] ?></td>
        </tr>
    <?php endforeach; ?>
</table>
