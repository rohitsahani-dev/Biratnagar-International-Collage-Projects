<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
  <?php
function isPalindrome($word) {

    $word = strtolower($word);      
    $word = str_replace(" ", "", $word); 
    $reverse = strrev($word);       

    if ($word == $reverse) {
        return true;
    } else {
        return false;
    }
}

if (isPalindrome("nurses run")) {
    echo "Palindrome";
} else {
    echo "Not Palindrome";
}
?>

</body>
</html>