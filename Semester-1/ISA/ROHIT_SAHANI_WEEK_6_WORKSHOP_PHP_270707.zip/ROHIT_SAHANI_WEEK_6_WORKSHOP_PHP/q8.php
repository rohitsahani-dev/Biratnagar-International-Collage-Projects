<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!DOCTYPE html>
<html>
<head>
    <title>Cities Array</title>
</head>
<body>

<?php
$cities = array(
    "Kathmandu", "Tokyo", "Mexico City", "New York City",
    "Mumbai", "Seoul", "Shanghai", "Lagos",
    "Buenos Aires", "Cairo", "London"
);

foreach ($cities as $city) {
    echo $city . ", ";
}


sort($cities);

echo "<ul>";
foreach ($cities as $city) {
    echo "<li>$city</li>";
}
echo "</ul>";

$cities[] = "Los Angeles";
$cities[] = "Calcutta";
$cities[] = "Osaka";
$cities[] = "Beijing";

sort($cities);
echo "<ul>";
foreach ($cities as $city) {
    echo "<li>$city</li>";
}
echo "</ul>";
?>

</body>
</html>

</body>
</html>