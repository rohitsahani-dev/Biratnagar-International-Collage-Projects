<!DOCTYPE html>
<html>
<head>
</head>
<body>
  <?php
function rectangle_area($width, $height) {
    $area = $width * $height;
    return "A rectangle of length $height and width $width has an area of $area.";
}

$width = 5;   
$height = 10; 

echo rectangle_area($width, $height);
?>

</body>
</html>
