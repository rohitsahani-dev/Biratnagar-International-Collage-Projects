<!DOCTYPE html>
<html>
<head>
    <title>City and Country</title>
</head>
<body>

<?php
// Associative array: country => city
$cities = array(
    "Nepal" => "Kathmandu",
    "Japan" => "Tokyo",
    "Mexico" => "Mexico City",
    "USA" => "New York City",
    "India" => "Mumbai",
    "Korea" => "Seoul",
    "China" => "Shanghai",
    "Nigeria" => "Lagos",
    "Argentina" => "Buenos Aires",
    "Egypt" => "Cairo",
    "England" => "London"
);

if (!isset($_POST['country'])) {
?>
    <form method="post">
        <p>Please choose a city:</p>
        <select name="country">
            <?php
            foreach ($cities as $country => $city) {
                echo "<option value=\"$country\">$city</option>";
            }
            ?>
        </select>

        <br><br>
        <input type="submit" value="Submit">
    </form>
<?php
} else {
    $country = $_POST['country'];
    $city = $cities[$country];
    echo "$city is in $country.";
}
?>
</body>
</html>
