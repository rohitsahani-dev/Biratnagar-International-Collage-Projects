<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="q5.city_process.php" method="post">
    Enter your favorite city:
    <input type="text" name="city">
    <input type="submit" value="Submit">
</form>
</body>
</html>