<?php
session_start();

if(isset($_POST['login'])){
    if($_POST['username']=="admin" && $_POST['password']=="123"){
        $_SESSION['user']="admin";
    } else {
        $e="Wrong login!";
    }
}

if(isset($_GET['logout'])){
    session_destroy();
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

if(isset($_SESSION['user'])){
    echo "Welcome, ".$_SESSION['user']."<br><a href='?logout'>Logout</a>";
} else {
    if(!empty($e)) echo $e."<br>";
    echo '<form method="post">
            <input name="username" placeholder="Username" required>
            <input name="password" type="password" placeholder="Password" required>
            <button name="login">Login</button>
          </form>';
}
?>
