<!DOCTYPE html>
<html>
<head>
    <title>Rectangle Area Calculator</title>
</head>
<body>
    <h2>Please enter the values of the length and width of your rectangle.</h2>

    <form method="post">
        Length: <input type="number" name="length"  required><br><br>
        Width: <input type="number" name="width"  required><br><br>
        <input type="submit" value="Calculate Area">
    </form>

    <?php

    if (!empty($_POST['length']) && !empty($_POST['width'])) {
        $length = $_POST['length'];
        $width = $_POST['width'];

       
        function rectangle_area($l, $w) {
            $area = $l * $w;
            return "A rectangle of length $l and width $w has an area of $area.";
        }

        echo "<h3>" . rectangle_area($length, $width) . "</h3>";
        
    }
    ?>
</body>
</html>
