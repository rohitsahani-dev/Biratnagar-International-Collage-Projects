<!DOCTYPE html>
<html>
<head>
    <title>Result</title>
</head>
<body>

<?php
$city = $_POST['city'];
echo "$city is your favorite city";
?>

</body>
</html>
`