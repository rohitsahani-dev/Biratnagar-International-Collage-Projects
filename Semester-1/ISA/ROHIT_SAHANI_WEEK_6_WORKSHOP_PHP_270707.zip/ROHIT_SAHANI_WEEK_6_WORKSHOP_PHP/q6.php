<!DOCTYPE html>
<html>
<head>
    <title>Favorite City</title>
</head>
<body>

<?php
if (!isset($_POST['city'])) {
?>
    <form method="post">
        Enter your favorite city:
        <input type="text" name="city">
        <input type="submit" value="Submit">
    </form>
<?php
} else {
    $city = $_POST['city'];
    echo "Your favorite city is $city.";
}
?>

</body>
</html>
